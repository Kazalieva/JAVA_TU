package lab4_2;

public class Building {
    int height;
    double area;
    String address;

    public Building(int height, double area,String address){
        this.height = height;
        this.area = area;
        this.address = address;
    }

    public int getHeight() {
        return height;
    }

    public double getArea() {
        return area;
    }

    public String getAddress() {
        return address;
    }

    public void setHeight(int height) throws HeightException {
        if (height < 0) {
            throw new HeightException();
        } else {
            this.height = height;
        }
    }

    public void setArea(double area) throws AreaException {
        if (area < 0) {
            throw new AreaException();
        } else {
            this.area = area;
        }
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String toString(){
        return "height = " + this.height + ",area = " + this.area + ",address = " + this.address;
    }
}

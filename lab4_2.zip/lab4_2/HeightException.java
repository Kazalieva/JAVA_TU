package lab4_2;

public class HeightException extends Exception{
    public String getMessage(){
        return "Enter a valid height!" ;
    }
}

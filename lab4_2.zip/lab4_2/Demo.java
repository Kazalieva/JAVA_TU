package lab4_2;

/*
Да се реализира клас Building, който описва дадена сграда с височина (цяло число метри), площ (число с плаваща запетая в кв.м)
и адрес (низ с произволна дължина). Да се реализира производен  клас  House,  който  допълнително  задава  брой  етажи  (цяло  число)
и  име  на собственик (низ с произволна дължина). За класовете да се реализират: подходящи селектори и мутатори;
методи за въвеждане от клавиатура и извеждане на екрана; метод, който по даден масив от къщи намира най-просторната къща,
т.е. тази с най-голяма средна височина на етаж. Създайте подходящи ваши изключения. Създайте клас с main метод,
в който да тествате работоспособността на приложението.
 */
public class Demo {
    public static void main(String[] args) {


        House[] houses = new House[3];
        try{

            houses[0]= new House(54,256.25,"Stefan Akademik 13",4,"Ivan");
            houses[1]= new House(10,26.25,"Akademik 13",1,"Gosho");
            houses[2]= new House(154,456.25,"Ivan Asen 17",28,"Alexa");
            houses[0].setHeight(4);
            houses[0].setArea(-54.2);
        }
        catch (HeightException |AreaException e){
            System.err.println(e.getMessage());
        }

        if(houses != null){
            for(House house : houses){
                System.out.println( "height = " + house.height + ",area = " + house.area + ",address = " + house.address);
            }
        }

        System.out.println("The largest house is: " + House.largestHouse(houses));
    }
}

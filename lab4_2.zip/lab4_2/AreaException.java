package lab4_2;

public class AreaException extends Exception{
    public String getMessage(){
        return "Enter a valid area!";
    }
}

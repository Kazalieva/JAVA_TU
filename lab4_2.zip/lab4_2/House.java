package lab4_2;

public class House extends Building{
    int floors;
    String name;

    public House(int height, double area,String address,int floors,String name){
        super(height,area,address);
        this.floors = floors;
        this.name = name;
    }

    public int getFloors() {
        return floors;
    }

    public String getName() {
        return name;
    }

    public void setFloors(int floors) {
        this.floors = floors;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static House largestHouse(House[] houses){
        double maxHigh = 0;
        House temp = null;

        for (House house : houses){
            if(house != null){
                double avrg = (double) house.getHeight() / house.getFloors();
                if(avrg>maxHigh){
                    maxHigh = avrg;
                    temp = house;
                }
            }
        }
        return temp;
    }
}

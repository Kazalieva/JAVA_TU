
    // Java program to create a connection to a database

import java.sql.*;

    public class connection {

        // Connection instance
        Connection con = null;

        public static Connection connectDB() {
            try {
                Class.forName("com.mysql.jdbc.Driver");

                Connection con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/food_delivery",
                        "root", "aysel13579.asd");


                return con;
            } catch (SQLException | ClassNotFoundException e) {

                System.out.println(e);
            }
            return null;
        }
    }


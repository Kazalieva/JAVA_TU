package com.company.msg;

import java.util.List;

public class Order {
    private User user;
    private Restaurant restaurant;
    private List<MenuItems> orders;

    public Order(User user, Restaurant restaurant, List<MenuItems> orders){
        this.user = user;
        this.restaurant = restaurant;
        this.orders = orders;
    }
    public double calculateTotalPrice(){
        double price = 0;
        for(MenuItems item : orders) {
            price += item.getPrice();
        }
        if(price < 49.0)
        {
            price +=5;
            System.out.println("The delivery is 5.00 $.");
        }
        System.out.println("You have free delivery!");
        return price;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public List<MenuItems> getOrders() {
        return orders;
    }

    public void setOrders(List<MenuItems> orders) {
        this.orders = orders;
    }



    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Information about the order:\n");
        for (MenuItems item : orders) {
            builder.append(item.toString());
        }
        System.out.println("\n");
        builder.append("Personal information: " + user.getUsername() + ", " + user.getPhone() + ", " + user.getCity() + "\n");
        return builder.toString();
    }
    }

package com.company.msg;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        try {

            Connection myConn = DriverManager.getConnection("\"jdbc:mysql://localhost:3306/foodDeliveryProject\",\n" +
                                                                                                "\"root\", \"aysel13579.asd\"");


            Statement mySmt = myConn.createStatement();

            ResultSet myRsMenu = mySmt.executeQuery("select * from menuItems");
            List<MenuItems> menuItems = new ArrayList<>();

            while (myRsMenu.next()) {
                System.out.println(myRsMenu.getString("name") + "," + myRsMenu.getString("price") + myRsMenu.getString("gr"));
                String name = myRsMenu.getString("name");
                double price = myRsMenu.getDouble("price");
                double gr = myRsMenu.getDouble("gr");
                MenuItems items = new MenuItems(name,price,gr);
                menuItems.add(items);
            }


            ResultSet myRsUser = mySmt.executeQuery("select * from users");
            List<User> users = new ArrayList<>();

            while (myRsUser.next()) {
                System.out.println(myRsUser.getString("username") + "," + myRsUser.getString("phone") + myRsUser.getString("city"));
                String username = myRsUser.getString("username");
                String phone = myRsUser.getString("phone");
                String city = myRsUser.getString("city");
                User user = new User(username, phone, city);
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }















        //Restaurant restaurant = new Restaurant("Djanum","Tsar Osvoboditel",5.6, menuItems);

        //User user1 = new User("Aneta Pavlova","123456","0883333333","Sofia");


        //user1.createOrder(restaurant);
        OrdersDB.printOrders();

    }
}

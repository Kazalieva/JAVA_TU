package com.company.msg;

import java.sql.*;

public class JDBCConfiguration {
    public static void main(String[] args) {
        try {
            //1. Get a connection to database
            Connection myConn = DriverManager.getConnection("\"jdbc:mysql://localhost:3306/foodDeliveryProject\",\n" +
                    "                                                                        \"root\", \"13579Qwe.r\"");

            //2.Create a statement
            Statement mySmt = myConn.createStatement();

            ResultSet myRs = mySmt.executeQuery("select * from users");

            //4. Process the result set
            while (myRs.next()) {
                System.out.println(myRs.getString("username") + "," + myRs.getString("password"));
            }

            //close the resources
            myConn.close();
            myRs.close();
            mySmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


// Java Program to Update contents in a table

import java.sql.*;
public class UpdateContent {

    public static void main(String[] args)
    {
        Connection con = null;
        PreparedStatement p = null;
        con = connection.connectDB();
        try {
            String sql
                    = "update restaurant set name='MSG' where id=2";
            p = con.prepareStatement(sql);
            p.execute();
        }
        catch (SQLException e) {
            System.out.println(e);
        }
    }
}

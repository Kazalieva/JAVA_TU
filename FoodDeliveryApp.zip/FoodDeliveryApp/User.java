package com.company.msg;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class User {
    private String username;
    private String phone;
    private String city;

    public User(String username,String phone, String city){
        this.username = username;
        this.phone = phone;
        this.city = city;
    }

    public void createOrder(Restaurant restaurant){
        Scanner scanner = new Scanner(System.in);
        List<MenuItems> order = new ArrayList<>();
        System.out.println(restaurant.getMenu());
        System.out.println("Welcome! What do you want :)?\n");
        while (true){
            String name = scanner.nextLine();
            if (name.equalsIgnoreCase("stop")){
                break;
            }
            for (MenuItems item : restaurant.getMenu()) {
                if (name.equals(item.getName())) {
                    order.add(item);
                }
            }
        }

        Order newOrder = new Order(this, restaurant, order);
        double total = newOrder.calculateTotalPrice();
        OrdersDB.orderList.add(newOrder);
        System.out.println("$" + total);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }


}

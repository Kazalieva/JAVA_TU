package com.company.msg;

public class MenuItems {
    private String name;
    private double price;
    private double gr;

    public MenuItems(String name, double price, double gr){
        this.name = name;
        this.price = price;
        this.gr = gr;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getGr() {
        return gr;
    }

    public void setGr(double gr) {
        this.gr = gr;
    }

    @Override
    public String toString() {
        return
                "name - " + name +
                ", price - " + price +
                ", gr - " + gr + "\n";
    }
}

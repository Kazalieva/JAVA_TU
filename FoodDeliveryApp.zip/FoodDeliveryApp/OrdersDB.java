package com.company.msg;

import java.util.ArrayList;
import java.util.List;

public class OrdersDB {
    public static List<Order> orderList = new ArrayList<>();

    public static void printOrders(){
        System.out.println(orderList);
    }
}

// Java code producing output which is based
// on values stored inside the "restaurants" table in DB

import java.sql.*;

    public class GetContent {

        // Step1: Main driver method
        public static void main(String[] args)
        {
            // Step 2: Making connection using
            // Connection type and inbuilt function on
            Connection con = null;
            PreparedStatement p = null;
            ResultSet rs = null;


            con = connection.connectDB();

            // Try block to catch exception/s
            try {

                // SQL command data stored in String datatype
                String sql = "select * from restaurants";
                p = con.prepareStatement(sql);
                rs = p.executeQuery();


                System.out.println("id\t\tname\t\tcity\t\taddress\t\trating\t\tphone");

                // Condition check
                while (rs.next()) {

                    int id = rs.getInt("id");
                    String name = rs.getString("name");
                    String city = rs.getString("city");
                    String address = rs.getString("address");
                    double rating = rs.getDouble("rating");
                    String phone = rs.getString("phone");
                    System.out.println(id + "\t\t" + name
                            + "\t\t" + city +"\t\t" + address + "\t\t" + rating + "\t\t" + phone);
                }
            }

            // Catch block to handle exception
            catch (SQLException e) {

                // Print exception pop-up on screen
                System.out.println(e);
            }
        }
    }





import java.io.BufferedReader;
        import java.io.IOException;
        import java.io.InputStreamReader;
        import java.io.PrintWriter;
        import java.net.Socket;
        import java.util.Scanner;

public class ClientMain {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 8080)) {
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            Scanner sc = new Scanner(System.in);
            String line = null;

            while (!"exit".equalsIgnoreCase(line)) {
                System.out.println("Server replied: " + in.readLine());
                line = sc.nextLine();
                out.println(line);
                out.flush();
            }

            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
import java.io.*;
        import java.util.ArrayList;
        import java.util.Collections;
        import java.util.List;

public class UserDB {
    public static List<User> users = Collections.synchronizedList(new ArrayList<>());

    public static void SafeUsers(List<User> users){
        synchronized (users) {
            try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("user.bin"))) {
                objectOutputStream.writeObject(users);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static List<User> LoadUsers(){
        try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("user.bin"))){
            Object obj = objectInputStream.readObject();
            if (obj instanceof List<?>){
                return (List<User>) obj;
            }
        } catch (IOException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
}
import lectures.test_example.db.UserDB;
        import lectures.test_example.utils.UserType;

public class Admin extends User {
    private static final Admin admin = new Admin("admin", "admin");

    private Admin(String user, String password) {
        super(user, password);
    }

    public static Admin getAdmin() {
        return admin;
    }

    @Override
    public UserType getUserType() {
        return UserType.ADMIN;
    }

    public User CreateUser(UserType userType, String user, String password) {
        switch (userType) {
            case TEACHER -> {
                Teacher teacher = new Teacher(user, password);
                UserDB.users.add(teacher);
                UserDB.SafeUsers(UserDB.users);
                return teacher;
            }
            case STUDENT -> {
                Student student = new Student(user, password);
                UserDB.users.add(student);
                UserDB.SafeUsers(UserDB.users);
                return student;
            }
            default -> {
                return null;
            }
        }
    }
}
public class Student extends User{
    private ArrayList<Grade> grades;

    public Student(String user, String password) {
        super(user, password);
        this.grades = new ArrayList<>();
    }

    public static boolean isValidateUser(String user) {
        Pattern pattern = Pattern.compile("[0-9]{9}");
        return pattern.matcher(user).matches();
    }

    public static boolean isValidatePassword(String password) {
        Pattern pattern = Pattern.compile("[0-9]{10}");
        return pattern.matcher(password).matches();
    }

    @Override
    public UserType getUserType() {
        return UserType.STUDENT;
    }

    public ArrayList<Grade> getGrades() {
        return grades;
    }

    public String printSortedGrades() {
        this.grades.sort(Comparator.comparing(Grade::getSemester).thenComparing(Grade::getSubject));
        StringBuffer buffer = new StringBuffer();
        for(Grade grade : grades){
            buffer.append(grade);
        }
        return buffer.toString();
    }

    public void setGrade(Grade grade) {
        this.grades.add(grade);
    }

}
public class Teacher extends User{
    public Teacher(String user, String password) {
        super(user, password);
    }

    public void addGrade(String facNumber, Grade grade){
        List<User> users = UserDB.LoadUsers();
        if (users != null) {
            for (User user: users){
                if (user.getUserType() == UserType.STUDENT && user.getUser().equals(facNumber)){
                    Student st = (Student)user;
                    st.setGrade(grade);
                    break;
                }
            }
            UserDB.SafeUsers(users);
        }
    }

    public static boolean isValidateUser(String user) {
        Pattern pattern = Pattern.compile("[A-Za-z]+@tu-sofia.com");
        return pattern.matcher(user).matches();
    }

    public static boolean isValidPassword(String password) {
        Pattern pattern = Pattern.compile(".{5,}");
        return pattern.matcher(password).matches();
    }

    @Override
    public UserType getUserType() {
        return UserType.TEACHER;
    }
}
public abstract class User implements Serializable {
    private String user;
    private String password;

    public User(String user, String password) {
        this.user = user;
        this.password = password;
    }

    public abstract UserType getUserType();

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
public class Grade implements Serializable {
    private String subject;
    private double grade;
    private int semester;

    public Grade(String subject, double grade, int semester) {
        this.subject = subject;
        this.grade = grade;
        this.semester = semester;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Grade grade1 = (Grade) o;

        if (Double.compare(grade1.grade, grade) != 0) return false;
        if (semester != grade1.semester) return false;
        return subject.equals(grade1.subject);
    }

    @Override
    public int hashCode() {
        int result;
        long temp;
        result = subject.hashCode();
        temp = Double.doubleToLongBits(grade);
        result = 31 * result + (int) (temp ^ (temp >>> 32));
        result = 31 * result + semester;
        return result;
    }

    @Override
    public String toString() {
        return "Grade{" + "subject='" + subject + '\'' + ", grade=" + grade + ", semester=" + semester + '}';
    }
}
public enum UserType {
    ADMIN, STUDENT, TEACHER
}
public class ClientResolver implements Runnable {
    private final Socket client;
    Admin admin = Admin.getAdmin();

    public ClientResolver(Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        BufferedReader reader;
        PrintWriter writer;
        try {
            writer = new PrintWriter(client.getOutputStream(), true);
            reader = new BufferedReader(new InputStreamReader(client.getInputStream()));

            writer.println("Enter username and password: ");
            String[] input = reader.readLine().split(" ");
            String username = input[0];
            String password = input[1];
            if (username.equals("admin") && password.equals("admin")) {
                openAdminCommunication(writer, reader);
            }
            if (Teacher.isValidateUser(username) && Teacher.isValidPassword(password)) {
                Teacher teacher = (Teacher) admin.CreateUser(UserType.TEACHER, username, password);
                openTeacherCommunication(writer, reader, teacher);
            }
            if (Student.isValidateUser(username) && Student.isValidatePassword(password)) {
                Student student = (Student) admin.CreateUser(UserType.STUDENT, username, password);
                openStudentCommunication(writer, student);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void openAdminCommunication(PrintWriter writer, BufferedReader reader) {
        try {
            writer.println("Welcome master");
            String userType = reader.readLine();
            if (userType.equalsIgnoreCase(String.valueOf(UserType.TEACHER))) {
                admin.CreateUser(UserType.TEACHER, reader.readLine(), reader.readLine());
            }
            if (userType.equalsIgnoreCase(String.valueOf(UserType.STUDENT))) {
                admin.CreateUser(UserType.STUDENT, reader.readLine(), reader.readLine());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void openStudentCommunication(PrintWriter writer, Student student) {
        writer.println(student.printSortedGrades());
    }

    private void openTeacherCommunication(PrintWriter writer, BufferedReader reader, Teacher teacher) {
        try {
            writer.println("Enter student id");
            String facNumber = reader.readLine();
            writer.println("Enter new grade");
            Grade grade = new Grade(reader.readLine(),
                    Double.parseDouble(reader.readLine()),
                    Integer.parseInt(reader.readLine()));
            teacher.addGrade(facNumber, grade);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
public class ServerMain {
    public static void main(String[] args) {
        ServerSocket server = null;
        try {
            server = new ServerSocket(8080);
            while (true){
                Socket client = server.accept();
                ClientResolver clientResolver = new ClientResolver(client);
                new Thread(clientResolver).start();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if(server != null){
                try {
                    server.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }

    }
}
package lab4_1;

public class PriceException extends Exception{
    public String getMessage() {
        return "Price is not correct";
    }
}

package lab4_1;

public class Books extends Stock{
    String author;
    String title;

    public Books(double price,int artNumber,String author,String title){
        super(price,artNumber);
        this.author = author;
        this.title = title;
    }

    @Override
    public double checkPromo() {
        return this.getPrice() - this.getPrice()*9/100;
    }

    public String getAuthor(){
        return author;
    }

    public void setAuthor(String author){
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}

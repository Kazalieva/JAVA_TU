package lab4_1;

/*
1. Създайте абстрактен клас Стоки, съдържащ информация за артикули в търговскаверига: цена и номер на артикул.
Създайте необходимите конструктори и get/setметоди. В класа да се реализира абстрактен метод public abstract doublecheckPromo(),
който изчислява нова цена при даден процент отстъпка. Нека класът Стоки да се наследи от класовете Книги и Телевизори,
съдържащи информация съответно за автор и заглавие, както и за производител, модел и мощност.
Създайте интерфейс ElectricalAppliance, който има1 абстрактен метод, изчисляващ разхода наелектроенергия.
Нека класът Телевизори да имплементира този интерфейс.Създайте ваши изключения PriceException и PowerException
като предефиниратеметода getMessage(). Създайте тестов клас, в който да демонстрирате работоспособността на програмата,
създавайки обекти от тип Книга и Телевизор.Нека промоционалната цена на телевизорите да е намалена с 9 %, а на книгите с15 %
 */
public class Demo {
    public static void main(String[] args) {

    Books book1 = null;
    TVs tv1 = null;
        try {
            book1 = new Books(25.10,154,"Lauren Kate","Fallen");
            tv1 = new TVs(200.90,100,"Lenovo","Lenovo S28",250.2);
            tv1.setPower(-52.2);
            book1.setPrice(54);
        }
        catch (PriceException | PowerException e){
            System.out.println(e.getMessage());
        }


        if (tv1 != null){
            System.out.println("Promo tv: " + tv1.checkPromo());
        }
        if (book1 != null){
            System.out.println("Promo book: " + book1.checkPromo());
        }

        System.out.println(tv1.energyConsume());
    }
}

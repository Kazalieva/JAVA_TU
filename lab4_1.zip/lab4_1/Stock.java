package lab4_1;


/* Създайте абстрактен клас Стоки, съдържащ информация за артикули в търговскаверига: цена и номер на артикул.
Създайте необходимите конструктори и get/setметоди. В класа да се реализира абстрактен метод
public abstract doublecheckPromo(), който изчислява нова цена при даден процент отстъпка.
Нека класътСтоки да се наследи от класовете Книги и Телевизори, съдържащи информациясъответно за автор и заглавие,
както и за производител, модел и мощност. Създайтеинтерфейс ElectricalAppliance, който има1 абстрактен метод,
изчисляващ разхода наелектроенергия. Нека класът Телевизори да имплементира този интерфейс.
Създайте ваши изключения PriceException и PowerException като предефиниратеметода getMessage().
Създайте тестов клас, в който да демонстриратеработоспособността на програмата, създавайки обекти от тип Книга и Телевизор.
Нека промоционалната цена на телевизорите да е намалена с 9 %, а на книгите с15 %
 */

public abstract class Stock {
    double price;
    int artNumber;

    public Stock(double price,int artNumber){
        this.price = price;
        this.artNumber = artNumber;
    }

    public double getPrice() {
        return price;
    }

    public int getArtNumber() {
        return artNumber;
    }

    public void setPrice(double price) throws PriceException {
        if(price < 0 ) {
            throw new PriceException();
        }else{
            this.price = price;
            }
        }


    public void setArtNumber(int artNumber) {
        this.artNumber = artNumber;
    }

    public abstract double checkPromo();
}

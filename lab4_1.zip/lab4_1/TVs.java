package lab4_1;

public class TVs extends Stock implements ElectricalAppliance{
    String manufacturer;
    String model;
    double power;

    public TVs(double price, int artNumber, String manufacturer, String model, double power) {
        super(price, artNumber);
        this.manufacturer = manufacturer;
        this.model = model;
        this.power = power;
    }

    @Override
    public double checkPromo() {
        return this.getPrice() - this.getPrice() * 15 / 100;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void getModel(String model) {
        this.model = model;
    }

    public double getPower() {
        return power;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setPower(double power) throws PowerException {
        if (power < 0) {
            throw new PowerException();
        } else {
            this.power = power;
        }
    }

    @Override
    public double energyConsume() {
        //измислена формула
        double energy = this.power*0.4;
        return energy;
    }
}
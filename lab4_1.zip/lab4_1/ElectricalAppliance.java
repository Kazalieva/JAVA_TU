package lab4_1;

public abstract interface ElectricalAppliance {
    public  double energyConsume();
}

package lab4_1;

public class PowerException extends Exception{
    public String getMessage() {
        return "Power value is not correct";
    }
}

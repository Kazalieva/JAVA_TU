import java.util.Set;

public class Test {

    public static void main(String[] args) throws IncorrectSolution {
        testSolveWithSingleSolution();
        testSolveWithMultipleSolution();
        testSolveWithNoSolution();
    }


    public static void testSolveWithSingleSolution() throws IncorrectSolution {
        Cube c1 = new Cube('R', 'R', 'R', 'R', 'R', 'R');
        Cube c2 = new Cube('Y', 'Y', 'Y', 'Y', 'Y', 'Y');
        Cube c3 = new Cube('B', 'B', 'B', 'B', 'B', 'B');
        Cube c4 = new Cube('G', 'G', 'G', 'G', 'G', 'G');

        CubePuzzle cubePuzzle = new CubePuzzle(c1, c2, c3, c4);


        Set<CubeStack> solutions = cubePuzzle.stackCubes();
        for (CubeStack solution : solutions) {
            System.out.println("-----------------");
            solution.printCubes();
        }

        if (solutions.size() != 1) {
            throw new IncorrectSolution(
                    "Actual Value: " + solutions.size() + " is different then expected: 1");
        }
    }


    public static void testSolveWithMultipleSolution() throws IncorrectSolution {
        Cube c1 = new Cube('B', 'B', 'B', 'Y', 'Y', 'Y');
        Cube c2 = new Cube('R', 'R', 'R', 'G', 'G', 'G');
        Cube c3 = new Cube('B', 'B', 'B', 'R', 'R', 'R');
        Cube c4 = new Cube('Y', 'Y', 'Y', 'G', 'G', 'G');

        CubePuzzle cubePuzzle = new CubePuzzle(c1, c2, c3, c4);


        Set<CubeStack> solutions = cubePuzzle.stackCubes();
        for (CubeStack solution : solutions) {
            System.out.println("-----------------");
            solution.printCubes();
        }

        if (solutions.size() != 10) {
            throw new IncorrectSolution(
                    "Actual Value: " + solutions.size() + " is different then expected: 10");
        }
    }


    public static void testSolveWithNoSolution() throws IncorrectSolution {
        Cube c1 = new Cube('B', 'B', 'B', 'B', 'B', 'B');
        Cube c2 = new Cube('Y', 'Y', 'Y', 'B', 'B', 'B');
        Cube c3 = new Cube('G', 'G', 'G', 'B', 'B', 'B');
        Cube c4 = new Cube('R', 'R', 'R', 'B', 'B', 'B');

        CubePuzzle cubePuzzle = new CubePuzzle(c1, c2, c3, c4);


        Set<CubeStack> solutions = cubePuzzle.stackCubes();
        for (CubeStack solution : solutions) {
            System.out.println("-----------------");
            solution.printCubes();
        }

        if (solutions.size() != 0) {
            throw new IncorrectSolution(
                    "Actual Value: " + solutions.size() + " is different then expected: 0");
        }
    }
}


public class IncorrectSolution extends RuntimeException{
    public IncorrectSolution(String message){
        super(message);
    }
}


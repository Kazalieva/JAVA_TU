import java.util.Set;

public class Main {
    public static void main(String[] args) {

        final String input = args[0];

        final String[] split = input.split(",");
        char[] c1In = split[0].trim().toCharArray();
        char[] c2In = split[1].trim().toCharArray();
        char[] c3In = split[2].trim().toCharArray();
        char[] c4In = split[3].trim().toCharArray();

        final Cube cube1 = new Cube(c1In[0], c1In[1], c1In[2], c1In[3], c1In[4], c1In[5]);
        final Cube cube2 = new Cube(c2In[0], c2In[1], c2In[2], c2In[3], c2In[4], c2In[5]);
        final Cube cube3 = new Cube(c3In[0], c3In[1], c3In[2], c3In[3], c3In[4], c3In[5]);
        final Cube cube4 = new Cube(c4In[0], c4In[1], c4In[2], c4In[3], c4In[4], c4In[5]);

        final CubePuzzle cubePuzzle = new CubePuzzle(cube1, cube2, cube3, cube4);
        final Set<CubeStack> stacks = cubePuzzle.stackCubes();

        System.out.println("The number of valid solutions are: " + stacks.size());


        for (final CubeStack stack : stacks) {
            System.out.println("-----------------------------------");
            for (Cube cube : stack.getCubes()) {
                System.out.println(cube.toString());
            }
        }
    }
}







import java.util.HashSet;
import java.util.Set;

public class CubePuzzle {
    private final Cube c1;
    private final Cube c2;
    private final Cube c3;
    private final Cube c4;


    public CubePuzzle(final Cube c1, final Cube c2, final Cube c3, final Cube c4) {
        this.c1 = c1;
        this.c2 = c2;
        this.c3 = c3;
        this.c4 = c4;
    }

    public Set<CubeStack> stackCubes() {
        final Set<Cube> c1Variants = c1.rotateAll();
        final Set<Cube> c2Variants = c2.rotateAll();
        final Set<Cube> c3Variants = c3.rotateAll();
        final Set<Cube> c4Variants = c4.rotateAll();

        final Set<CubeStack> stacks = new HashSet<>();

        for (final Cube c1Var : c1Variants) {
            for (final Cube c2Var : c2Variants) {
                for (final Cube c3Var : c3Variants) {
                    for (final Cube c4Var : c4Variants) {
                        boolean front = !c1Var.equalsFrontSide(c2Var) && !c1Var.equalsFrontSide(c3Var)
                                && !c1Var.equalsFrontSide(c4Var) && !c2Var.equalsFrontSide(c3Var)
                                && !c2Var.equalsFrontSide(c4Var) && !c3Var.equalsFrontSide(c4Var);
                        boolean back = !c1Var.equalsBackSide(c2Var) && !c1Var.equalsBackSide(c3Var)
                                && !c1Var.equalsBackSide(c4Var) && !c2Var.equalsBackSide(c3Var)
                                && !c2Var.equalsBackSide(c4Var) && !c3Var.equalsBackSide(c4Var);
                        boolean left = !c1Var.equalsLeftSide(c2Var) && !c1Var.equalsLeftSide(c3Var)
                                && !c1Var.equalsLeftSide(c4Var) && !c2Var.equalsLeftSide(c3Var)
                                && !c2Var.equalsLeftSide(c4Var) && !c3Var.equalsLeftSide(c4Var);
                        boolean right = !c1Var.equalsRightSide(c2Var) && !c1Var.equalsRightSide(c3Var)
                                && !c1Var.equalsRightSide(c4Var) && !c2Var.equalsRightSide(c3Var)
                                && !c2Var.equalsRightSide(c4Var) && !c3Var.equalsRightSide(c4Var);

                        if (front && back && left & right) {
                            stacks.add(new CubeStack(c1Var, c2Var, c3Var, c4Var));
                        }
                    }
                }
            }
        }

         return stacks;
    }
}








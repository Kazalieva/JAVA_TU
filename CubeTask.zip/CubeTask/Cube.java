import java.util.HashSet;
import java.util.Set;

public class Cube {
    private final char front;
    private final char back;
    private final char left;
    private final char right;
    private final char top;
    private final char bottom;

    public Cube(char front, char back, char left, char right, char top, char bottom) {
        this.front = front;
        this.back = back;
        this.left = left;
        this.right = right;
        this.top = top;
        this.bottom = bottom;
    }

    public Cube turnFrontToRight_X() {
        Cube variantX = new Cube(this.left, this.right, this.back, this.front, this.top, this.bottom);
        return variantX;
    }

    public Cube turnTopToRight_Y() {
        Cube variantY = new Cube(this.front, this.back, this.bottom, this.top, this.left, this.right);
        return variantY;
    }

    public Cube turnTopToBack_Z() {
        Cube variantZ = new Cube(this.bottom,this.top,this.left,this.right,this.front,this.back);
        return variantZ;
    }

    public Set<Cube> rotateAll() {
        Set<Cube> allVariants = new HashSet<>();

        Cube current = this;
        for (int i = 1; i <= 4; i++) {
            current = current.turnTopToRight_Y();
            for (int j = 1; j <= 4; j++) {
                current = current.turnFrontToRight_X();
                allVariants.add(current);
            }
        }

        for (int i = 1; i <= 4; i++) {
            current = current.turnTopToBack_Z();
            for (int j = 1; j <= 4; j++) {
                current = current.turnFrontToRight_X();
                allVariants.add(current);
            }
        }

        return allVariants;
    }


    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        } else if (obj == this) {
            return true;
        } else if (obj instanceof Cube) {
            Cube c = (Cube) obj;
            return front == c.front && back == c.back
                    && left == c.left && right == c.right
                    && top == c.top && bottom == c.bottom;
        } else
            return false;
    }

    @Override
    public int hashCode() {
        return Character.hashCode(front) + Character.hashCode(back) + Character.hashCode(left) +
                Character.hashCode(right) + Character.hashCode(top) + Character.hashCode(bottom);
    }

    public String toString() {
        return "\t"+ this.front + " " + this.back + " " +
                this.left + " " + this.right + " " + this.top + " " + this.bottom;
    }


    public char getFront() {
        return front;
    }
    public char getBack() {
        return back;
    }
    public char getLeft() {
        return left;
    }
    public char getRight() {
        return right;
    }
    public char getTop() {
        return top;
    }
    public char getBottom() {
        return bottom;
    }

    public boolean equalsFrontSide(Cube anotherCube){
        return  this.front == anotherCube.front;
    }

    public boolean equalsBackSide(Cube anotherCube){
        return  this.back == anotherCube.back;
    }

    public boolean equalsLeftSide(Cube anotherCube){
        return  this.left == anotherCube.left;
    }

    public boolean equalsRightSide(Cube anotherCube){
        return  this.right == anotherCube.right;
    }

    public boolean equalsAllSides(Cube anotherCube){
        return  equalsFrontSide(anotherCube) && equalsBackSide(anotherCube)
                && equalsLeftSide(anotherCube) && equalsRightSide(anotherCube);
    }
}







import java.util.Arrays;

public class CubeStack {
    final private Cube[] cubes;

    public Cube getFirst(){
        return cubes[0];
    }
    public Cube getSecond(){
        return cubes[1];
    }
    public Cube getThird(){
        return cubes[2];
    }
    public Cube getFourth(){
        return cubes[3];
    }


    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final CubeStack stack = (CubeStack) o;

        return getFirst().equalsAllSides(stack.getFirst())
                && getSecond().equalsAllSides(stack.getSecond())
                && getThird().equalsAllSides(stack.getThird())
                && getFourth().equalsAllSides(stack.getFourth());
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(cubes);
    }

    public CubeStack(final Cube... cubes) {
        this.cubes = cubes;
    }

    public Cube[] getCubes() {
        return cubes;
    }

    public void printCubes() {
        for (Cube cube : cubes) {
            System.out.println(cube.toString());
        }
    }
}



package lab_6;

public class NoMoreProductsException extends Exception{
    public String getMessage(){
        return "NoMoreProductsException";
    }
}

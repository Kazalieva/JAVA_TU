package lab_6;

import java.io.IOException;

public interface ImportDate {
    Object[] importDataFromFile() throws IOException;
}

package lab_6;

public class WrongPhoneNumberException extends Exception{
    public String getMessage(){
        return "WrongPhoneNumberException";
    }

}

package lab5;

public class WrongPhoneNumberException extends Exception{
    public String getMessage(){
        return "WrongPhoneNumberException";
    }
}

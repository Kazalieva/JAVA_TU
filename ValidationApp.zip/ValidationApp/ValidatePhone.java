package lab5;

public interface ValidatePhone {
    boolean validatePhoneNumber(String phoneNumber);
}

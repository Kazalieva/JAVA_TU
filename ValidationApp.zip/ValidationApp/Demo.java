package lab5;

import java.util.Scanner;

/*
Създайте клас User,съдържащ информация за потребителско име, паролаи телефонен номер.
Напишете  конструктор  с  параметри  и  създайте необходимите get/setметоди.
Напишете клас, който валидира потребителски именавъз основа на следните изисквания:
• може да съдържатбукви от a-z малки;
• може да съдържати цифрите от 0-9;
• може да съдържатдолна черта или тире;
• дължината на всяко потребителско име може да бъдеот 3 до 15 символа.
По аналогичен начин реализирайте клас, който валидира дали избраната от всеки потребител парола отговаря на следните изисквания:
• минимална дължина11символа;
•може да съдържасамобукви a-zи A-Z.
Реализирайте  собствени  изключения –WrongUserException  и WrongPhoneNumberException.
Напишете интерфейс ValidatePhone, съдържащ статичен метод boolean validatePhoneNumber(String phoneNumber),
който се имплементира от класа User. Нека при непълен или грешен (съдържащ не само цифри) номер да се хвърля WrongPhoneNumberException.
Създайте тестов клас, в който при стартиране на програмата на потребителя се предлагат следните 2 опции–регистрация или вход.
При избор на първата се прави проверка за вече съществуващо потребителско име в предварително създаден  масив  от  тип User,
съответни  проверки  за  валидация  на потребителско име, парола и телефонен номер(необходимое потребителят да  въведе  два  пъти избраната  парола).
При  избор  навтората  опция е необходимо да се направи проверка в масива с потребители и в зависимост от резултата да се изведат подходящи съобщения.
 */

/*
public class Demo {
    public static void main(String[] args) {

        User[] users = new User[10];

        users[0].name = "alexa";
        users[0].phone = "0885487596";
        users[0].password = "45478as";

        users[1].name = "sam";
        users[1].phone = "088548787";
        users[1].password = "_a45478as";


        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter an option: registration / login ?");
        String answer = scanner.nextLine();
        answer.toLowerCase();

        if (answer.equals("registration")) {
            String newUser = scanner.nextLine();
            String newPassword = scanner.nextLine();
            String confirmPassword = scanner.nextLine();
            String newPhone = scanner.nextLine();
            String messageR = register(newUser,newPassword,confirmPassword,newPhone);
            System.out.println(messageR);

        } else if (answer.equals("login")) {
            String username = scanner.nextLine();
            String password = scanner.nextLine();
            String loginMessage = login(username, password);
            System.out.println(loginMessage);

        } else {
            System.out.println("Error! Try again!");
        }
    }

    public static String login(String username, String password) {
        for (User user : users) {
            if (user.getName().equals(username) && user.getPassword().equals(password)) {
                return "Login is successful :)";
            }
        }
        return "Login is NOT successful :(";
    }

    public  static String register(String newUser, String newPassword, String confirmPassword, String newPhone ){
        for(User user:users){
            if(user.getName().equals(newUser)){
                return "You already have a profile!";
            }
        }
        if(!newPassword.equals(confirmPassword)){
            return "Passwords are NOT the same!";
        }
        try{
            users.add(new User(newUser,newPassword,newPhone));
        }catch (WrongPasswords | WrongPhoneNumberException | WrongUserException e){
            System.out.println(e.getMessage());
        }
return "Welcome!";
    }
}
*/



package lab5;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhoneValidation {

       private Pattern pattern;
        private Matcher matcher;

        private static String phonePattern = "^[0-9_-]{10}$";

        public PhoneValidation(){
            pattern = Pattern.compile(phonePattern);
        }
        public boolean validateUserName(String phone){
            matcher = pattern.matcher(phone);
            return matcher.matches();
        }

    }


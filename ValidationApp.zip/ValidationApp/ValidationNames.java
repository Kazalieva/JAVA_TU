package lab5;

import java.lang.reflect.ParameterizedType;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationNames {

    private Pattern pattern;
    private Matcher matcher;

    private static String usernamePattern = "^[a-z0-9_-]{3,15}$";

    public ValidationNames(){
        pattern = Pattern.compile(usernamePattern);
    }
    public boolean validateUserName(String username){
        matcher = pattern.matcher(username);
        return matcher.matches();
    }


}

package lab5;

import java.lang.reflect.ParameterizedType;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationPasswords {
    private Pattern pattern;
    private Matcher matcher;

    private static String password = "^[a-zA-Z]{11,}$";

    public ValidationPasswords(){
        pattern = Pattern.compile(password);
    }
    public boolean validatePassword(String password){
        matcher = pattern.matcher(password);
        return matcher.matches();
    }


}

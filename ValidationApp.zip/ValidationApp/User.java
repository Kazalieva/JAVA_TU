package lab5;
import lab_6.WrongPhoneNumberException;

import java.lang.reflect.ParameterizedType;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class User implements ValidatePhone{
    String name;
    String password;
    String phone;

    public User(String name, String password, String phone) throws WrongPhoneNumberException,WrongUserException{
        this.name = name;
        this.password = password;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) throws WrongUserException{
       ValidationNames validationNames = new ValidationNames();
        if(validationNames.validateUserName(name)){
            this.name = name;
        }else{
            throw new WrongUserException();
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) throws WrongPasswords {
        ValidationPasswords validationPasswords = new ValidationPasswords();
        if (validationPasswords.validatePassword(password)) {
            this.password = password;
        } else {
            throw new WrongPasswords();
        }
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) throws WrongPhoneNumberException {
        PhoneValidation phoneValidation = new PhoneValidation();
        if(phoneValidation.validateUserName(phone)){
            this.phone = phone;
        }else {
            throw new WrongPhoneNumberException();
        }
    }


    @Override
    public boolean validatePhoneNumber(String phoneNumber) {
        return false;
    }
}

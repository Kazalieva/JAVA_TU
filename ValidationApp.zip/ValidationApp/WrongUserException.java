package lab5;

public class WrongUserException extends Exception{
    public String getMessage(){
        return "WrongUserException";
    }
}

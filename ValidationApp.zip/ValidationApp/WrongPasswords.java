package lab5;

public class WrongPasswords extends Exception{
    public String getMessage(){
        return "Wrong password!";
    }
}
